<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.x/css/materialdesignicons.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

	<!-- FAVICON -->

	<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
	<link rel="manifest" href="/site.webmanifest">
	<meta name="msapplication-TileColor" content="#2d89ef">
	<meta name="theme-color" content="#ffffff">

	<!-- FAVICON -->

	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/estilo-gral.css">
	<link rel="stylesheet" type="text/css" href="fonts/fonts.css">
	<link rel="stylesheet" type="text/css" href="fonts/fonts_gral.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<link rel="stylesheet" href="footer/estilos/footer.css">

	<title>TECNICA 7 'JH'-Contáctenos</title>
</head>
<body>

	<!-- apertura del tag core -->
<template id="app">
	<v-app>
		<v-navigation-drawer
			app
			v-model="menu"
			temporary
			class="text-center white--text"
		>
			<template>
			  <v-card
			    width="300"
			    tile
			  >
			     <v-img
			        contain
			        class="mt-n4"
				      :src="cover.srcDefault"
				      height="100px"
				    ></v-img>
			    <v-list
			      dense
			    	v-for="(item, i) in header.links"
				    :key="i">

			      <v-list-item
			      	v-if="!item.subItems.length"
			      	:href="item.href"
			      	link
			      >
			        <v-list-item-icon>
			          <v-icon></v-icon>
			        </v-list-item-icon>
			        <v-list-item-title class="text-left">{{item.texto}}</v-list-item-title>
			      </v-list-item>

			      <v-list-group
			          v-else
			          no-action
			        >
				          <template v-slot:activator>
				          	<v-list-item-icon>
						          <v-icon></v-icon>
						        </v-list-item-icon>
				            <v-list-item-content>
				              <v-list-item-title class="text-left">{{item.texto}}</v-list-item-title>
				            </v-list-item-content>
				          </template>

				          <v-list-item
				          	v-for="(subItem, i) in item.subItems"
				    				:key="i"
				    				:href="subItem.href"
				            link
				          >
				            <v-list-item-title
				            	class="text-left"
				            	v-text="subItem.texto"></v-list-item-title>
				            	<v-list-item-icon>
							          <v-icon></v-icon>
							        </v-list-item-icon>
				          </v-list-item>
			        </v-list-group>
			    </v-list>
			    <v-divider></v-divider>
			    <v-list>
			      <v-list-item dense>

			        <v-list-item-content>
			          <v-list-item-title>4201 0621</v-list-item-title>
			          <v-list-item-subtitle>Tel.Fax:</v-list-item-subtitle>
			        </v-list-item-content>
			      </v-list-item>

					 <v-divider inset></v-divider>

			      <v-list-item dense>
			        <v-list-item-content>
			          <v-list-item-title>eest7avellaneda@abc.gob.ar</v-list-item-title>
			          <v-list-item-subtitle>Email Official</v-list-item-subtitle>
			        </v-list-item-content>
			      </v-list-item>

			      <v-divider inset></v-divider>
			    <v-divider inset></v-divider>
					<v-list-item dense>

			        <v-list-item-content>
			          <v-list-item-title>Ing. Marconi 745</v-list-item-title>
			          <v-list-item-subtitle>Buenos Aires, Avellaneda, 1870</v-list-item-subtitle>
			        </v-list-item-content>
			      </v-list-item>
			    </v-list>
			  </v-card>
			</template>
		</v-navigation-drawer>

		<!-- src="https://lh5.googleusercontent.com/X0sznMr_c1nthE3eGJGI1f2VaHaZcBgfDNv2opIU--KDfGS6THtVb2ijTTAQGeBmrLzhPLm-hw=w16383" -->
		<v-app-bar
			app
			flat
			elevate-on-scroll
			hide-on-scroll
			:color="header.color"
			class=" white--text"
			>
			<!-- -->
			<v-app-bar-nav-icon
				class="hidden-md-and-up"
				@click.stop="menu = !menu"
			></v-app-bar-nav-icon>

			<v-toolbar-title>
				<a :href="docRoot">
					<v-img
					:width="$vuetify.breakpoint.smAndDown ? '49' : '65'"
					:src="logo"
					></v-img>
				</a>
			</v-toolbar-title>
			<a
				:href="docRoot"
				style="color: white;"
				class="text-decoration-none"
			>
				<h1 class="ml-5" v-if="$vuetify.breakpoint.smAndDown">{{title}}</h1>
			</a>
			<v-menu
			  v-if="!$vuetify.breakpoint.smAndDown"
				v-for="(item, i) in header.links"
				transition="slide-y-transition"
				bottom
				offset-y
				open-on-hover
			>
				<template v-slot:activator="{ on }">
					<v-btn
						text
						small
						:color="header.color"
						class="lighten-1 white--text caption"
						v-on="on"
						:href="item && item.href"
					>
						{{ item.texto }}
					</v-btn>
				</template>
					<v-list
					v-if="item.subItems.length"
					:color="header.menuColor"
					>
						<v-list-item
						v-for="(subItem, i) in item.subItems"
						:key="i"
						:href="subItem && subItem.href"
						>
							<v-list-item-content>
								<v-list-item-title
								v-text="subItem.texto"
								class="lighten-1 white--text caption"
								:color="header.color"
								>
								</v-list-item-title>
							</v-list-item-content>
						</v-list-item>
					</v-list>
			</v-menu>
		</v-app-bar>
        <!-- Sizes your content based upon application components -->
        <v-main>
            <!-- Provides the application the proper gutter -->
            <v-container fluid>
				<v-row>
                    <v-col sm="12" md="12" cols="12">
					<h1 class="titulo"> Formulario para Consultas</h1><hr class="uno"><br />
                        <v-row align="center" justify="center">
							
							<div id="contact"></div>
                        </v-row> 
                    </v-col>
                </v-row>
				
			</v-container>
	    </v-main>
  <template>
	<v-footer
	  app
	  :color="footer.color"
	  class="mt-10"
	  padless
	  absolute
	>
	  <v-row
		justify="center"
		no-gutters
	  >
		<v-btn
		  v-for="(link, key) in footer.links"
		  :key="key"
		  :href="link.href"
		  color="white"
		  text
		  rounded
		  class="my-2"
		>
		  {{ link.texto }}
		</v-btn>
		<v-col
		  class="indigo accent-2 text-center white--text"
		  cols="12"
		>
		Email Official: eest7avellaneda@abc.gob.ar | Tel.Fax: 4201 0621 | Ing. Marconi 745, Buenos Aires, Avellaneda, 1870
		</v-col>
		<v-col
		  class="indigo accent-3 text-center white--text"
		  cols="12"
		>
		{{ new Date().getFullYear() }} — <strong>Técnica n°7, José Hernández</strong>
		</v-col>
	  </v-row>
	</v-footer>
  </template>
<!-- cierre del tag core -->
</v-app>
</template>
  <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/shell.js"></script>
  <script src="/js/jquery.js" ></script>
<script src="/js/main.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/vue@2.x/dist/vue.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.js"></script>
<script src="/js/core12072023v1.js" ></script>
  <script>
	'use strict';
	(function(){
		hbspt.forms.create({
			portalId: "8039443",
			formId: "58b3e823-39ab-4376-bd4e-89d568291a75",
			target: "#contact"
		});
	})();
  </script>
</body>
</html>